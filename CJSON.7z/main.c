#include <stdio.h>
#include <stdlib.h>
#include "cJSON.h"

int main() {
	printf("========== cJSON 完整示例 ==========\n\n");
	
	/* 1. 创建基本 JSON 对象 */
	printf("1. 创建基本 JSON 对象:\n");
	cJSON *root = cJSON_CreateObject();
	cJSON_AddStringToObject(root, "name", "张三");
	cJSON_AddNumberToObject(root, "age", 25);
	cJSON_AddBoolToObject(root, "is_student", 1);
	cJSON_AddNullToObject(root, "car");
	
	// 打印 JSON
	char *json_str = cJSON_Print(root);
	printf("基本对象: %s\n\n", json_str);
	free(json_str);
	
	/* 2. 创建嵌套对象 */
	printf("2. 创建嵌套对象:\n");
	cJSON *address = cJSON_CreateObject();
	cJSON_AddStringToObject(address, "city", "北京");
	cJSON_AddStringToObject(address, "street", "中关村大街");
	cJSON_AddItemToObject(root, "address", address);
	
	// 紧凑打印
	json_str = cJSON_PrintUnformatted(root);
	printf("紧凑格式: %s\n\n", json_str);
	free(json_str);
	
	/* 3. 创建数组 */
	printf("3. 创建数组:\n");
	cJSON *hobbies = cJSON_CreateArray();
	cJSON_AddItemToArray(hobbies, cJSON_CreateString("编程"));
	cJSON_AddItemToArray(hobbies, cJSON_CreateString("游戏"));
	cJSON_AddItemToArray(hobbies, cJSON_CreateString("阅读"));
	cJSON_AddItemToObject(root, "hobbies", hobbies);
	
	// 添加数字到数组
	cJSON_AddItemToArray(hobbies, cJSON_CreateNumber(42));
	
	// 打印当前 JSON
	json_str = cJSON_Print(root);
	printf("添加数组后: %s\n\n", json_str);
	free(json_str);
	
	/* 4. 数组操作 */
	printf("4. 数组操作:\n");
	// 获取数组大小
	int array_size = cJSON_GetArraySize(hobbies);
	printf("数组大小: %d\n", array_size);
	
	// 获取数组元素
	cJSON *first_hobby = cJSON_GetArrayItem(hobbies, 0);
	printf("第一个爱好: %s\n", first_hobby->valuestring);
	
	// 插入元素
	cJSON_InsertItemInArray(hobbies, 1, cJSON_CreateString("游泳"));
	
	// 删除元素
	cJSON_DeleteItemFromArray(hobbies, 3); // 删除数字42
	
	// 迭代数组
	printf("所有爱好: ");
	cJSON *hobby = NULL;
	cJSON_ArrayForEach(hobby, hobbies) {
		if (cJSON_IsString(hobby)) {
			printf("%s ", hobby->valuestring);
		}
	}
	printf("\n\n");
	
	/* 5. 修改对象值 */
	printf("5. 修改对象值:\n");
	// 修改字符串值
	cJSON_SetValuestring(cJSON_GetObjectItem(root, "name"), "李四");
	
	// 修改数字值
	cJSON *age_item = cJSON_GetObjectItem(root, "age");
	cJSON_SetNumberValue(age_item, 30);
	
	// 添加新字段
	cJSON_AddNumberToObject(root, "score", 95.5);
	
	json_str = cJSON_Print(root);
	printf("修改后对象: %s\n\n", json_str);
	free(json_str);
	
	/* 6. 解析 JSON 字符串 */
	printf("6. 解析 JSON 字符串:\n");
	const char *json_data = 
	"{"
	"\"company\": \"Tech Inc.\","
	"\"employees\": ["
	"{\"name\":\"Alice\", \"position\":\"Developer\"},"
	"{\"name\":\"Bob\", \"position\":\"Designer\"}"
	"],"
	"\"active\": true"
	"}";
	
	cJSON *parsed = cJSON_Parse(json_data);
	if (!parsed) {
		const char *error_ptr = cJSON_GetErrorPtr();
		if (error_ptr) {
			fprintf(stderr, "解析错误: %s\n", error_ptr);
		}
		return 1;
	}
	
	// 访问解析后的数据
	cJSON *company = cJSON_GetObjectItemCaseSensitive(parsed, "company");
	printf("公司名称: %s\n", company->valuestring);
	
	cJSON *employees = cJSON_GetObjectItemCaseSensitive(parsed, "employees");
	cJSON *employee;
	printf("员工列表:\n");
	cJSON_ArrayForEach(employee, employees) {
		cJSON *name = cJSON_GetObjectItemCaseSensitive(employee, "name");
		cJSON *position = cJSON_GetObjectItemCaseSensitive(employee, "position");
		printf("  - %s (%s)\n", name->valuestring, position->valuestring);
	}
	
	// 检查布尔值
	cJSON *active = cJSON_GetObjectItemCaseSensitive(parsed, "active");
	if (cJSON_IsBool(active)) {
		printf("公司活跃状态: %s\n\n", active->valueint ? "是" : "否");
	}
	
	/* 7. 引用和内存管理 */
	printf("7. 引用和内存管理:\n");
	// 创建字符串引用（不复制内存）
	const char *constant_str = "常量字符串";
	cJSON *ref_item = cJSON_CreateStringReference(constant_str);
	cJSON_AddItemToObject(root, "constant", ref_item);
	
	// 创建对象引用
	cJSON *ref_obj = cJSON_CreateObjectReference(address);
	cJSON_AddItemToObject(root, "address_ref", ref_obj);
	
	// 打印并展示引用
	json_str = cJSON_Print(root);
	printf("添加引用后: %s\n", json_str);
	free(json_str);
	
	// 删除主对象（引用不会被删除）
	cJSON_Delete(root);
	printf("主对象已删除，常量字符串仍然存在: %s\n\n", constant_str);
	
	/* 8. 其他实用功能 */
	printf("8. 其他实用功能:\n");
	// 使用缓冲区打印
	char buffer[256];
	int result = cJSON_PrintPreallocated(parsed, buffer, sizeof(buffer), 1);
	if (result) {
		printf("缓冲打印: %s\n", buffer);
	} else {
		printf("缓冲区不足!\n");
	}
	
	// 检查类型
	cJSON *item = cJSON_GetObjectItem(parsed, "company");
	if (cJSON_IsString(item) && item->valuestring != NULL) {
		printf("company 是字符串类型\n");
	}
	
	// 深拷贝
	cJSON *copy = cJSON_Duplicate(parsed, 1);
	cJSON_Delete(parsed);
	printf("深拷贝成功，原始对象已删除\n");
	
	// 清理复制的对象
	cJSON_Delete(copy);
	
	printf("\n========== 示例完成 ==========\n");
	return 0;
}
