/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/*
 * This example shows how can application implement RX and TX DMA for UART.
 * It uses simple packet example approach and 3 separate buffers:
 *
 * - Raw DMA RX buffer where DMA transfers data from UART to memory
 * - Ringbuff for RX data which are processed by application
 * - Ringbuff for TX data to send using TX DMA
 */
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "lwrb.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ARRAY_LEN(x) (sizeof(x) / sizeof((x)[0]))
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void usart_rx1_check(void);
void usart1_process_data(const void *data, size_t len);
void usart1_send_string(const char *str);
uint8_t usart_start_tx1_dma_transfer(void);

void usart_rx2_check(void);
void usart2_process_data(const void *data, size_t len);
void usart2_send_string(const char *str);
uint8_t usart_start_tx2_dma_transfer(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t    usart_rx1_dma_buffer[128];
uint8_t    usart_rx2_dma_buffer[128];

lwrb_t    usart_rx1_rb;
lwrb_t    usart_rx2_rb;

uint8_t    usart_rx1_rb_data[128];
uint8_t    usart_rx2_rb_data[128];

lwrb_t    usart_tx1_rb;
lwrb_t usart_tx2_rb;

uint8_t    usart_tx1_rb_data[128];
uint8_t    usart_tx2_rb_data[128];

volatile size_t    usart_tx1_dma_current_len;
volatile size_t    usart_tx2_dma_current_len;
/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  uint8_t state, cmd, len;

  lwrb_init(&usart_tx1_rb, usart_tx1_rb_data, sizeof(usart_tx1_rb_data));
  lwrb_init(&usart_rx1_rb, usart_rx1_rb_data, sizeof(usart_rx1_rb_data));
  lwrb_init(&usart_tx2_rb, usart_tx2_rb_data, sizeof(usart_tx2_rb_data));
  lwrb_init(&usart_rx2_rb, usart_rx2_rb_data, sizeof(usart_rx2_rb_data));

  HAL_UARTEx_ReceiveToIdle_DMA(&huart1, usart_rx1_dma_buffer, sizeof(usart_rx1_dma_buffer));
  HAL_UARTEx_ReceiveToIdle_DMA(&huart2, usart_rx2_dma_buffer, sizeof(usart_rx2_dma_buffer));

  //  state = 0;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    // 串口1接收的数据转发到串口2
    size_t rx1_size = lwrb_get_full(&usart_rx1_rb);
    if (rx1_size > 0)
    {
      uint8_t rx1_data[rx1_size];
      lwrb_read(&usart_rx1_rb, rx1_data, rx1_size);
      lwrb_write(&usart_tx2_rb, rx1_data, rx1_size);
      usart_start_tx2_dma_transfer();
    }

    // 串口2接收的数据转发到串口1
    size_t rx2_size = lwrb_get_full(&usart_rx2_rb);
    if (rx2_size > 0)
    {
      uint8_t rx2_data[rx2_size];
      lwrb_read(&usart_rx2_rb, rx2_data, rx2_size);
      lwrb_write(&usart_tx1_rb, rx2_data, rx2_size);
      usart_start_tx1_dma_transfer();
    }

    // 可以添加其他任务...
  }
  /* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
   * in the RCC_OscInitTypeDef structure.
   */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
   */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

void usart_rx1_check(void)
{
  static size_t old_pos;
  size_t pos;

  /* Calculate current position in buffer and check for new data available */
  pos = ARRAY_LEN(usart_rx1_dma_buffer) - __HAL_DMA_GET_COUNTER(&hdma_usart1_rx);
  if (pos != old_pos)
  { /* Check change in received data */
    if (pos > old_pos)
    { /* Current position is over previous one */
      usart1_process_data(&usart_rx1_dma_buffer[old_pos], pos - old_pos);
    }
    else
    {
      usart1_process_data(&usart_rx1_dma_buffer[old_pos], ARRAY_LEN(usart_rx1_dma_buffer) - old_pos);
      if (pos > 0)
      {
        usart1_process_data(&usart_rx1_dma_buffer[0], pos);
      }
    }
    old_pos = pos; /* Save current position as old for next transfers */
  }
}
void usart_rx2_check(void)
{
  static size_t old_pos;
  size_t pos;

  /* Calculate current position in buffer and check for new data available */
  pos = ARRAY_LEN(usart_rx2_dma_buffer) - __HAL_DMA_GET_COUNTER(&hdma_usart2_rx);
  if (pos != old_pos)
  { /* Check change in received data */
    if (pos > old_pos)
    { /* Current position is over previous one */

      usart2_process_data(&usart_rx2_dma_buffer[old_pos], pos - old_pos);
    }
    else
    {

      usart2_process_data(&usart_rx2_dma_buffer[old_pos], ARRAY_LEN(usart_rx2_dma_buffer) - old_pos);
      if (pos > 0)
      {
        usart2_process_data(&usart_rx2_dma_buffer[0], pos);
      }
    }
    old_pos = pos; /* Save current position as old for next transfers */
  }
}

uint8_t usart_start_tx1_dma_transfer(void)
{
  uint32_t primask;
  uint8_t started = 0;

  primask = __get_PRIMASK();
  __disable_irq();

  if (usart_tx1_dma_current_len == 0 &&
      (usart_tx1_dma_current_len = lwrb_get_linear_block_read_length(&usart_tx1_rb)) > 0)
  {
    if (HAL_OK == HAL_UART_Transmit_DMA(&huart1,
                                        (uint8_t *)lwrb_get_linear_block_read_address(&usart_tx1_rb),
                                        usart_tx1_dma_current_len))
    {
      started = 1;
    }
  }

  __set_PRIMASK(primask);
  return started;
}
uint8_t usart_start_tx2_dma_transfer(void)
{
  uint32_t primask;
  uint8_t started = 0;

  primask = __get_PRIMASK();
  __disable_irq();

  if (usart_tx2_dma_current_len == 0 &&
      (usart_tx2_dma_current_len = lwrb_get_linear_block_read_length(&usart_tx2_rb)) > 0)
  {
    if (HAL_OK == HAL_UART_Transmit_DMA(&huart2,
                                        (uint8_t *)lwrb_get_linear_block_read_address(&usart_tx2_rb),
                                        usart_tx2_dma_current_len))
    {
      started = 1;
    }
  }

  __set_PRIMASK(primask);
  return started;
}

void usart1_process_data(const void *data, size_t len)
{
  lwrb_write(&usart_rx1_rb, data, len); /* Write data to receive buffer */
}
void usart2_process_data(const void *data, size_t len)
{
  lwrb_write(&usart_rx2_rb, data, len); /* Write data to receive buffer */
}

void usart1_send_string(const char *str)
{
  lwrb_write(&usart_tx1_rb, str, strlen(str)); /* Write data to transmit buffer */
  usart_start_tx1_dma_transfer();
}
void usart2_send_string(const char *str)
{
  lwrb_write(&usart_tx2_rb, str, strlen(str)); /* Write data to transmit buffer */
  usart_start_tx2_dma_transfer();
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart == &huart1)
  {
    usart_rx1_check();
  }
  if (huart == &huart2)
  {
    usart_rx2_check();
  }
}
void HAL_UART_RxHalfCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart == &huart1)
  {
    usart_rx1_check();
  }
  if (huart == &huart2)
  {
    usart_rx2_check();
  }
}
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
  if (huart == &huart1)
  {
    usart_rx1_check();
  }
  if (huart == &huart2)
  {
    usart_rx2_check();
  }
}
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart == &huart1)
  {
    lwrb_skip(&usart_tx1_rb, usart_tx1_dma_current_len); /* Skip sent data, mark as read */
    usart_tx1_dma_current_len = 0;                       /* Clear length variable */
    usart_start_tx1_dma_transfer();                      /* Start sending more data */
  }
  if (huart == &huart2)
  {
    lwrb_skip(&usart_tx2_rb, usart_tx2_dma_current_len); /* Skip sent data, mark as read */
    usart_tx2_dma_current_len = 0;                       /* Clear length variable */
    usart_start_tx2_dma_transfer();                      /* Start sending more data */
  }
}

/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
