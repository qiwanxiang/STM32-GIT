/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/*
 * This example shows how can application implement RX and TX DMA for UART.
 * It uses simple packet example approach and 3 separate buffers:
 *
 * - Raw DMA RX buffer where DMA transfers data from UART to memory
 * - Ringbuff for RX data which are processed by application
 * - Ringbuff for TX data to send using TX DMA
 */
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "lwrb.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ARRAY_LEN(x) (sizeof(x) / sizeof((x)[0]))
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void usart_rx_check(void);
void usart_process_data(const void *data, size_t len);
void usart_send_string(const char *str);
uint8_t usart_start_tx_dma_transfer(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t
    usart_rx_dma_buffer[64];

lwrb_t
    usart_rx_rb;

uint8_t
    usart_rx_rb_data[128];

lwrb_t
    usart_tx_rb;

uint8_t
    usart_tx_rb_data[128];

volatile size_t
    usart_tx_dma_current_len;
/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
  uint8_t state, cmd, len;

  lwrb_init(&usart_tx_rb, usart_tx_rb_data, sizeof(usart_tx_rb_data));
  lwrb_init(&usart_rx_rb, usart_rx_rb_data, sizeof(usart_rx_rb_data));

  HAL_UARTEx_ReceiveToIdle_DMA(&huart1, usart_rx_dma_buffer, sizeof(usart_rx_dma_buffer));
  usart_send_string("USART DMA example: DMA HT & TC + USART IDLE LINE interrupts\r\n");
  usart_send_string("Start sending data to STM32\r\n");

  state = 0;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

    uint8_t b;

    /* Process RX ringbuffer */

    /* Packet format: START_BYTE, CMD, LEN[, DATA[0], DATA[len - 1]], STOP BYTE */
    /* DATA bytes are included only if LEN > 0 */
    /* An example, send sequence of these bytes: 0x55, 0x01, 0x01, 0xFF, 0xAA */

    /* Read byte by byte */

    if (lwrb_read(&usart_rx_rb, &b, 1) == 1)
    {
      switch (state)
      {
      case 0:
      { /* Wait for start byte */
        if (b == 0x55)
        {
          ++state;
        }
        break;
      }
      case 1:
      { /* Check packet command */
        cmd = b;
        ++state;
        break;
      }
      case 2:
      { /* Packet data length */
        len = b;
        ++state;
        if (len == 0)
        {
          ++state; /* Ignore data part if len = 0 */
        }
        break;
      }
      case 3:
      {        /* Data for command */
        --len; /* Decrease for received character */
        if (len == 0)
        {
          ++state;
        }
        break;
      }
      case 4:
      { /* End of packet */
        if (b == 0xAA)
        {
          /* Packet is valid */

          /* Send out response with CMD = 0xFF */
          b = 0x55; /* Start byte */
          lwrb_write(&usart_tx_rb, &b, 1);
          cmd = 0xFF; /* Command = 0xFF = OK response */
          lwrb_write(&usart_tx_rb, &cmd, 1);
          b = 0x00; /* Len = 0 */
          lwrb_write(&usart_tx_rb, &b, 1);
          b = 0xAA; /* Stop byte */
          lwrb_write(&usart_tx_rb, &b, 1);

          /* Flush everything */
          usart_start_tx_dma_transfer();
        }
        state = 0;
        break;
      }
      }
    }

    /* Do other tasks ... */
  }
  /* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
   * in the RCC_OscInitTypeDef structure.
   */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
   */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/**
 * \brief           Check for new data received with DMA
 *
 * User must select context to call this function from:
 * - Only interrupts (DMA HT, DMA TC, UART IDLE) with same preemption priority level
 * - Only thread context (outside interrupts)
 *
 * If called from both context-es, exclusive access protection must be implemented
 * This mode is not advised as it usually means architecture design problems
 *
 * When IDLE interrupt is not present, application must rely only on thread context,
 * by manually calling function as quickly as possible, to make sure
 * data are read from raw buffer and processed.
 *
 * Not doing reads fast enough may cause DMA to overflow unread received bytes,
 * hence application will lost useful data.
 *
 * Solutions to this are:
 * - Improve architecture design to achieve faster reads
 * - Increase raw buffer size and allow DMA to write more data before this function is called
 */
void usart_rx_check(void)
{
  static size_t old_pos;
  size_t pos;

  /* Calculate current position in buffer and check for new data available */
  pos = ARRAY_LEN(usart_rx_dma_buffer) - __HAL_DMA_GET_COUNTER(&hdma_usart1_rx);
  if (pos != old_pos)
  { /* Check change in received data */
    if (pos > old_pos)
    { /* Current position is over previous one */
      /*
       * Processing is done in "linear" mode.
       *
       * Application processing is fast with single data block,
       * length is simply calculated by subtracting pointers
       *
       * [   0   ]
       * [   1   ] <- old_pos |------------------------------------|
       * [   2   ]            |                                    |
       * [   3   ]            | Single block (len = pos - old_pos) |
       * [   4   ]            |                                    |
       * [   5   ]            |------------------------------------|
       * [   6   ] <- pos
       * [   7   ]
       * [ N - 1 ]
       */
      usart_process_data(&usart_rx_dma_buffer[old_pos], pos - old_pos);
    }
    else
    {
      /*
       * Processing is done in "overflow" mode..
       *
       * Application must process data twice,
       * since there are 2 linear memory blocks to handle
       *
       * [   0   ]            |---------------------------------|
       * [   1   ]            | Second block (len = pos)        |
       * [   2   ]            |---------------------------------|
       * [   3   ] <- pos
       * [   4   ] <- old_pos |---------------------------------|
       * [   5   ]            |                                 |
       * [   6   ]            | First block (len = N - old_pos) |
       * [   7   ]            |                                 |
       * [ N - 1 ]            |---------------------------------|
       */
      usart_process_data(&usart_rx_dma_buffer[old_pos], ARRAY_LEN(usart_rx_dma_buffer) - old_pos);
      if (pos > 0)
      {
        usart_process_data(&usart_rx_dma_buffer[0], pos);
      }
    }
    old_pos = pos; /* Save current position as old for next transfers */
  }
}

uint8_t usart_start_tx_dma_transfer(void)
{
  uint32_t primask;
  uint8_t started = 0;

  primask = __get_PRIMASK();
  __disable_irq();

  if (usart_tx_dma_current_len == 0 &&
      (usart_tx_dma_current_len = lwrb_get_linear_block_read_length(&usart_tx_rb)) > 0)
  {
    if (HAL_OK == HAL_UART_Transmit_DMA(&huart1,
                                        (uint8_t *)lwrb_get_linear_block_read_address(&usart_tx_rb),
                                        usart_tx_dma_current_len))
    {
      started = 1;
    }
  }

  __set_PRIMASK(primask);
  return started;
}
void usart_process_data(const void *data, size_t len)
{
  lwrb_write(&usart_rx_rb, data, len); /* Write data to receive buffer */
}
void usart_send_string(const char *str)
{
  lwrb_write(&usart_tx_rb, str, strlen(str)); /* Write data to transmit buffer */
  usart_start_tx_dma_transfer();
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  usart_rx_check();
}
void HAL_UART_RxHalfCpltCallback(UART_HandleTypeDef *huart)
{
  usart_rx_check();
}
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
  usart_rx_check(); /* Check for data to process */
}
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
  lwrb_skip(&usart_tx_rb, usart_tx_dma_current_len); /* Skip sent data, mark as read */
  usart_tx_dma_current_len = 0;                      /* Clear length variable */
  usart_start_tx_dma_transfer();                     /* Start sending more data */
}

/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
