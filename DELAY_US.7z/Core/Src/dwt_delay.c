#include "dwt_delay.h"

void DWT_Init(void)
{
    // 启用DWT
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0; // 清空计数器
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk; // 启动CYCCNT
}

// 微秒级延时
void DWT_Delay_us(uint32_t us)
{
    uint32_t start = DWT->CYCCNT;
    uint32_t ticks = us * (SystemCoreClock / 1000000UL);
    while ((DWT->CYCCNT - start) < ticks) {
        __NOP();
    }
}

// 毫秒级延时
void DWT_Delay_ms(uint32_t ms)
{
    for (uint32_t i = 0; i < ms; i++) {
        DWT_Delay_us(1000);
    }
}