#ifndef DWT_DELAY_H
#define DWT_DELAY_H

#include "main.h" 

void DWT_Init(void);
void DWT_Delay_us(uint32_t us);
void DWT_Delay_ms(uint32_t ms);

#endif